//
// Created by antoine on 05/12/2021.
//

#ifndef EVALUATION_EVENEMENT_H
#define EVALUATION_EVENEMENT_H


class Evenement {
public:

    int type;
    Phrase * text;
    int execute();
    Evenement();
    // Constructeur
    //
};


#endif //EVALUATION_EVENEMENT_H
