//
// Created by antoine on 17/11/2021.
//

#include "Equipement.h"

Equipement::Equipement(int i) {
    this->type = i ;
}
