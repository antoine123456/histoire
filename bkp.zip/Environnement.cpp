//
// Created by antoine on 17/11/2021.
//
#include "Personnage.h"
#include "Environnement.h"
#include "Equipement.h"
#include "Piece.h"
#include <string>
#include <vector>
Environnement::Environnement(std::string name)
{
    Equipement* arme = new Equipement(1);
    Equipement* armure = new Equipement(1);
    Personnage* res = new Personnage("bonjour",1,arme,armure,1);
    this->personnage = res;
    this->name  = name;
}

void Environnement::preparerPieces(){
    //TODO creer la classe piece qui interpr�te les instruction et creer leurs objet
    //TODO attribuer les num�ros aux pi�ces
    for(int i= 0 ; i<9; i++){
        Piece* piec = new Piece(i);//numero piece inutile
        piec->creerActionList();
        this->pieces.push_back(piec);
    }
    /*
    std::vector<int> inst = phrase->seekInstruction();
    std::cout << inst[1] <<"\n" ;
    Piece* piece =

            */
    //Piece->actionList.push_back() = phrase->extraire(0,inst[0]-1);
    //Piece->instr = phrase;
    //Piece->processInstr();
}
void Environnement::jouer(){
    int suite = 0;
    while(suite!=-1){
        suite = this->pieces[suite]->execActions();
        //std::cout << suite <<"\n" ;
        //system("pause");
    }
    std::cout << "Bye Bye" <<"\n" ;
    system("pause");
}