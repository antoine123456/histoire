//
// Created by antoine on 05/12/2021.
//
#include "Phrase.h"
#include "Fichier.h"
#include "Piece.h"
Piece::Piece(int numero) {
    this->numero = numero;
}
void Piece::creerActionList() {
    char name[20];
    //std::cout<<this->numero<<std::endl;
    sprintf(name, "texte/%d.txt", this->numero);
    Fichier fich(name);
    Phrase* contenu = fich.lireFichier();
    std::vector<Phrase*> inst =contenu->seekInstruction();
    for (auto const& i : inst){
        Evenement* intro = new Evenement();
        intro->text=i;
        //std::cout<<i->phrase[0]<<std::endl;
        this->actionList.push_back(intro);
    }
}
int Piece::execActions(){
    for (auto const& i : this->actionList){
        //std::cout<<"victoire"<<std::endl;
        //std::cout<<i->text->phrase[0]<<std::endl;
        //std::cout<<"thepb";
        int info = i->execute();
        //std::cout<<info<<std::endl;
        if(info!=-1) {
            return info;
        }
        //i->text->phrase[0];
    }
    return -1;
}
