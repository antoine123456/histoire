//
// Created by antoine on 05/12/2021.
//

#ifndef EVALUATION_PIECE_H
#define EVALUATION_PIECE_H
#include "Phrase.h"
#include <vector>
#include "Evenement.h"
class Piece {

private:
    int compte=0;
public:
    int numero;
    std::vector<Evenement*> actionList;//ordre
    int execActions();
    void creerActionList();
    //
    Piece(int);
};


#endif //EVALUATION_PIECE_H
