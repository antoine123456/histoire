//
// Created by antoine on 05/12/2021.
//

#include "Evenement.h"
#include <Windows.h>
Evenement::Evenement(){

}
int Evenement::execute(){
    //std::cout<<this->text->phrase[0]<<std::endl;
    if(this->text->phrase[0]=="*PATH*"){
        if(this->text->phrase[1]==this->text->phrase[2]){
            return std::stoi(this->text->phrase[1]);
        }
        int x=0;

        while(x>2 || x<1){
            std::cout<<"Chemin :";
            std::cin >> x; // Get user input from the keyboard
        }
        return std::stoi(this->text->phrase[x]);
    }else if(this->text->phrase[0]=="*COMBAT*"){
        std::cout<<"combat :"<<std::endl;
    }else if(this->text->phrase[0]=="*ARME*"){
        std::cout<<"arme :";
    }else if(this->text->phrase[0]=="*ARMURE*"){
        std::cout<<"armure :";
    }else if(this->text->phrase[0]=="*VICTOIRE*"){
        std::cout<<"victoire :";
    }else if(this->text->phrase[0]=="*GO*"){
        std::cout<<"fin :";
    }else{
        this->text->__repr__();

    }
    //std::cout<<"finEXEC"<<std::endl;
    return -1;
}