//
// Created by antoine on 17/11/2021.
//

#ifndef EVALUATION_EQUIPEMENT_H
#define EVALUATION_EQUIPEMENT_H


class Equipement {
private:
    int type;
    int PA;
public:
    Equipement(int i);
};


#endif //EVALUATION_EQUIPEMENT_H
